# Chromium is a free and open-source web browser project, mainly developed and maintained by Google. This codebase provides the vast majority of code for the Google Chrome browser, which is proprietary software and has some additional features. The Chromium codebase is widely used.
# This REPL makes posibble to run a browser in a IDE.

chromium-browser --no-sandbox "https://somafm.com/player/#/now-playing/groovesalad/"